import { Component, OnInit } from '@angular/core';

import {
  FormBuilder, FormGroup, Validators,
  FormControl
} from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';

import { Customer, Building, MyErrorStateMatcher } from '../../shared/models';
import { CustomerService, BuildingService } from '../../shared/services';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  // object used to store buildings information to use to pick building for the cstomer
  // on the autocomplete control
  buildings: Array<Building>;
  // object for customer information to be saved
  customer: Customer;
  // form group used for validation purpouses
  customerForm: FormGroup;
  // control used for the autocomplete control
  buildingsControl = new FormControl('', [Validators.required]);
  // custom matcher used to check valid input
  matcher = new MyErrorStateMatcher();
  // object used to show filtered elements on the autocomplete control
  filteredBuildings: Observable<Building[]>;

  constructor(private _customerService: CustomerService,
    private _buildingService: BuildingService,
    private _formBuilder: FormBuilder,
    public snackBar: MatSnackBar
    ) { }

  ngOnInit() {
    // create FormGroup for validation and send data
      this.customerForm = this._formBuilder.group({
        customer: ['', Validators.required],
        prefix: ['', Validators.required],
        available: true
      });

    // add the buildingsContrill autocomplete to the form group
    this.customerForm.addControl('building', this.buildingsControl);

    // load Buildings available
    this.getBuildings();
  }

  // convenience getter for easy access to form fields
  get f() { return this.customerForm.controls; }

  /**
   * Load all the buildings from web api
   */
  getBuildings() {
    this._buildingService.getBuildings().subscribe(
      buildings => {
        this.buildings = buildings;
        // bind filteredBuildings to control change to filter values when user is typing
        // this action is executed here to wait for buildings load
        this.filteredBuildings = this.buildingsControl.valueChanges
          .pipe(
            startWith<string | Building>(''),
            map(value => {
              if (value) {
                if (typeof value === 'string') {
                  return value;
                }
                return value.building;
              }
              return '';
            }),
            map(building => building ? this._filter(building) : this.buildings.slice())
          );
      }
    );
  }
  /**
   * Method triggered by the form submit used to save data
   */
  saveCustomer() {
    // stop here if form is invalid
    if (this.customerForm.invalid) {
      console.log(this.customerForm.errors);
      return;
    }
    // get customer information from the control
    this.customer = this.customerForm.value as Customer;
    // assign building id to specific model field
    this.customer.fk_buildings = this.customer.building.pk_building;
    // call saveCustomer method on customer service to save information
    this._customerService.saveCustomer(this.customer).subscribe(
      response => {
        // Show a snackbar to let the user know the customer was saved successfully
        this.snackBar.open('customer ' + this.customer.customer + ' saved successfully ', '', {
          duration: 1500,
        });
        // reset form group
        this.customerForm.reset();
      }
    );
  }

  /**
   * Function used to show the building name on the autocomplete
   * @param building building objet to get the building name
   */
  displayFn(building?: Building): string | undefined {
    return building ? building.building : undefined;
  }

  /**
   * Method used to update elements on the Building AutoComplete
   * @param value string to filter
   */
  private _filter(value: string): Building[] {
    const filterValue = value.toLowerCase();

    return this.buildings.filter(building => building.building.toLowerCase().includes(filterValue));
  }

}
