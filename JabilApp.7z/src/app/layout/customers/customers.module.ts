import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomersRoutingModule } from './customers-routing.module';
import { CustomersComponent } from './customers.component';
import { MaterialCompModule } from '../../material-comp.module';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    CustomersRoutingModule,
    MaterialCompModule,
    FlexLayoutModule
  ],
  declarations: [CustomersComponent]
})
export class CustomersModule { }
