import { Component, OnInit, ViewChild } from '@angular/core';

import {
  FormBuilder, FormGroup, Validators,
  FormControl
} from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';

import { Customer, PartNumber, MyErrorStateMatcher } from '../../shared/models';
import { CustomerService, PartNumberService, ExcelService } from '../../shared/services';

import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  customers: Array<Customer>;
  // object used for part number information
  partNumber: PartNumber;
  // objet used to handle better the information to be used for the find call
  partNumberForm: FormGroup;
  // control used for the autocomplete control
  customersControl = new FormControl('');
  // custom matcher used to check valid input
  matcher = new MyErrorStateMatcher();
  // object used to show filtered elements on the autocomplete control
  filteredCustomers: Observable<Customer[]>;
  // object used by Table control to show information
  displayedColumns = ['pk_part_number', 'part_number', 'available', 'Customer.customer', 'Customer.Building.building' ];
  // Object used to show  meaningfull infromation on headers about fields on the table
  columnNames = ['Part Number ID', 'Part Number', 'Available', 'Customer', 'Building' ];
  // object used for Table to show information
  dataSource = new MatTableDataSource<any>(new Array<any>());
  // object used to hide or show excel button
  infoRetrieved = false;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private _customerService: CustomerService,
    private _partNumberService: PartNumberService,
    private _excelService: ExcelService,
    private _formBuilder: FormBuilder,
    public snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    // create FormGroup for validation and send data
    this.partNumberForm = this._formBuilder.group({
      part_number: '',
      available: false,
      useOR: false
    });

    // add the buildingsContrill autocomplete to the form group
    this.partNumberForm.addControl('customer', this.customersControl);

    // load Buildings available
    this.getCustomers();

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // convenience getter for easy access to form fields
  get f() { return this.partNumberForm.controls; }

  /**
  * Load all the customers from web api
  */
  getCustomers() {
    this._customerService.getCustomers().subscribe(
      customers => {
        this.customers = customers;
        console.log(this.customers);
        // bind filteredBuildings to control change to filter values when user is typing
        // this action is executed here to waith for buildings load
        this.filteredCustomers = this.customersControl.valueChanges
          .pipe(
            startWith<string | Customer>(''),
            map(value => {
              if (value) {
                if (typeof value === 'string') {
                  return value;
                }
                return value.customer;
              }
              return '';
            }),
            map(customer => customer ? this._filter(customer) : this.customers.slice())
          );
      }
    );
  }

  /**
  * Function used to show the building name on the autocomplete
  * @param building building objet to get the building name
  */
  displayFn(customer?: Customer): string | undefined {
    return customer ? customer.customer : undefined;
  }

  /**
   * Method used to update elements on the Building AutoComplete
   * @param value string to filter
   */
  private _filter(value: string): Customer[] {
    const filterValue = value.toLowerCase();

    return this.customers.filter(customer => customer.customer.toLowerCase().includes(filterValue));
  }
  /**
   * Function used to access object properties based on string
   * this is used to show information on the table
   *
   * @param {*} obj The object that contains the property we need to get
   * @param {string} path the path to the property we need
   * @returns {string} value of the property
   * @memberof SearchComponent
   */
  getProperty(obj: any, path: string) {
    const result: any = path.split('.').reduce((o, p) => o && o[p], obj);
    if (typeof (result) === typeof (true)) {
      return result ? 'Yes' : 'No';
    }
    return result;
  }

  /**
   * Method triggered by the form submit used to get data
   */
  searchPartNumber() {
    // stop here if form is invalid
    if (this.partNumberForm.invalid) {
      console.log(this.partNumberForm.errors);
      return;
    }
    // set infoRetrieved to false to hide excel button
    this.infoRetrieved = false;
    // assign infromation to partNumber object from form group
    this.partNumber = this.partNumberForm.value as PartNumber;
    // assign customer id to specific model field if customer was selected
    if (this.partNumber.customer) {
      this.partNumber.fk_customers = this.partNumber.customer.pk_customer;
    }
    // call PartNumberSearch method of part number service to get information from web api
    this._partNumberService.PartNumberSearch(this.partNumber, this.f.useOR.value).subscribe(
      partNumbers => {
        if (partNumbers != null) {
           this.dataSource.data = partNumbers;
          // change infoRetrieved depending if data was retrieved to show excel button
          this.infoRetrieved = partNumbers.length ? true : false;
          console.log(this.dataSource.data);
        } else {
          // Show a snackbar to let the user know the partNumber was saved successfully
          this.snackBar.open('No information has been found ', '', {
            duration: 1500,
          });
        }
      }
    );
  }
  /**
   *Method used to export table to excel file
   *
   */
  generateExcel(): void {
    this._excelService.exportAsExcelFileCustomHeader(this.dataSource.data.map((part) => {
       return {
          id: part.pk_part_number,
          partNumber: part.part_number,
          available: part.available ? 'Yes' : 'No',
          customer: part.Customer.customer,
          building: part.Customer.Building.building
        };
      }), this.columnNames, 'PartNumbers');
  }

}
