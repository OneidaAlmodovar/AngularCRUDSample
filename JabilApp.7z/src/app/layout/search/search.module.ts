import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchRoutingModule } from './search-routing.module';
import { SearchComponent } from './search.component';

import { MaterialCompModule } from '../../material-comp.module';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    SearchRoutingModule,
    MaterialCompModule,
    FlexLayoutModule
  ],
  declarations: [SearchComponent]
})
export class SearchModule { }
