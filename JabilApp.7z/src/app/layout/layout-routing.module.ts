import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

/**
 * create rountes to lazy load all the modules
 */
const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'search'
      },
      {
        path: 'buildings',
        loadChildren: './buildings/buildings.module#BuildingsModule',
      },
      {
        path: 'customers',
        loadChildren: './customers/customers.module#CustomersModule',
      },
      {
        path: 'part-numbers',
        loadChildren: './part-numbers/part-numbers.module#PartNumbersModule',
      },
      {
        path: 'search',
        loadChildren: './search/search.module#SearchModule',
      }
    ]
  }
];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
