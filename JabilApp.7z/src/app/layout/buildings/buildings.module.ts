import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BuildingsRoutingModule } from './buildings-routing.module';
import { BuildingsComponent } from './buildings.component';
import { MaterialCompModule } from '../../material-comp.module';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    BuildingsRoutingModule,
    MaterialCompModule,
    FlexLayoutModule
  ],
  declarations: [BuildingsComponent]
})
export class BuildingsModule { }
