import { Component, OnInit } from '@angular/core';

import {
  FormBuilder, FormGroup, Validators,
  FormControl, FormGroupDirective, NgForm
} from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatSnackBar } from '@angular/material';

import { Building, MyErrorStateMatcher } from '../../shared/models';
import { BuildingService } from '../../shared/services';


@Component({
  selector: 'app-buildings',
  templateUrl: './buildings.component.html',
  styleUrls: ['./buildings.component.css']
})
export class BuildingsComponent implements OnInit {
  buildingForm: FormGroup;
  building: Building = new Building();
  // custom matcher to check for valid input
  matcher = new MyErrorStateMatcher();

  constructor(private _buildingService: BuildingService,
    private _formBuilder: FormBuilder,
    public snackBar: MatSnackBar,
    ) { }

  ngOnInit() {
    // initialize form group to help with validation
    this.buildingForm = this._formBuilder.group({
      building: ['', Validators.required],
      available: true
    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.buildingForm.controls; }
  /**
   * Method triggered by the form submit used to save data
   */
  saveBuilding() {
    // stop here if form is invalid
    if (this.buildingForm.invalid) {
      return;
    }
    this.building = this.buildingForm.value as Building;
    this._buildingService.saveBuilding(this.building).subscribe(
      response => {
        // Show a snackbar to let the user know the building was saved successfully
        this.snackBar.open('building ' + this.building.building + ' saved successfully ', '', {
          duration: 1500,
        });
        this.buildingForm.reset();
      }
    );
  }
}
