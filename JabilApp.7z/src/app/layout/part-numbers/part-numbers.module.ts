import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PartNumbersRoutingModule } from './part-numbers-routing.module';
import { PartNumbersComponent } from './part-numbers.component';

import { MaterialCompModule } from '../../material-comp.module';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    PartNumbersRoutingModule,
    MaterialCompModule,
    FlexLayoutModule
  ],
  declarations: [PartNumbersComponent]
})
export class PartNumbersModule { }
