import { Component, OnInit } from '@angular/core';

import {
  FormBuilder, FormGroup, Validators,
  FormControl
} from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';

import { Customer, PartNumber, MyErrorStateMatcher } from '../../shared/models';
import { CustomerService, PartNumberService } from '../../shared/services';

@Component({
  selector: 'app-part-numbers',
  templateUrl: './part-numbers.component.html',
  styleUrls: ['./part-numbers.component.css']
})
export class PartNumbersComponent implements OnInit {
  // object used to store customers information to use to pick building for the cstomer
  // on the autocomplete control
  customers: Array<Customer>;
  // object for part number information to be saved
  partNumber: PartNumber;
  // form group used for validation purpouses
  partNumberForm: FormGroup;
  // control used for the autocomplete control
  customersControl = new FormControl('', [Validators.required]);
  // custom matcher used to check valid input
  matcher = new MyErrorStateMatcher();
  // object used to show filtered elements on the autocomplete control
  filteredCustomers: Observable<Customer[]>;
  constructor(
    private _customerService: CustomerService,
    private _partNumberService: PartNumberService,
    private _formBuilder: FormBuilder,
    public snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.prepareFormGroup();
    // load Buildings available
    this.getCustomers();
  }

  prepareFormGroup() {
    // create FormGroup for validation and send data
    this.partNumberForm = this._formBuilder.group({
      part_number: ['', Validators.required],
      available: true
    });

    // add the buildingsContrill autocomplete to the form group
    this.partNumberForm.addControl('customer', this.customersControl);
  }

  // convenience getter for easy access to form fields
  get f() { return this.partNumberForm.controls; }

   /**
   * Load all the customers from web api
   */
  getCustomers() {
    this._customerService.getCustomers().subscribe(
      customers => {
        this.customers = customers;
        console.log(this.customers);
        // bind filteredBuildings to control change to filter values when user is typing
        // this action is executed here to waith for buildings load
        this.filteredCustomers = this.customersControl.valueChanges
          .pipe(
            startWith<string | Customer>(''),
            map(value => {
              if (value) {
                if (typeof value === 'string') {
                  return value;
                }
                return value.customer;
              }
              return '';
            }),
            map(customer => customer ? this._filter(customer) : this.customers.slice())
          );
      }
    );
  }

  /**
  * Function used to show the building name on the autocomplete
  * @param building building objet to get the building name
  */
  displayFn(customer?: Customer): string | undefined {
    return customer ? customer.customer : undefined;
  }

  /**
   * Method used to update elements on the Building AutoComplete
   * @param value string to filter
   */
  private _filter(value: string): Customer[] {
    const filterValue = value.toLowerCase();
    return this.customers.filter(customer => customer.customer.toLowerCase().includes(filterValue));
  }

  /**
   * Method triggered by the form submit used to save data
   */
  savePartNumber() {
    // stop here if form is invalid
    if (this.partNumberForm.invalid) {
      console.log(this.partNumberForm.errors);
      return;
    }
    this.partNumber = this.partNumberForm.value as PartNumber;
    // assign customer id to specific model field
    this.partNumber.fk_customers = this.partNumber.customer.pk_customer;
    console.log(this.partNumber);
    this._partNumberService.savePartNumber(this.partNumber).subscribe(
      response => {
        // Show a snackbar to let the user know the partNumber was saved successfully
        this.snackBar.open('partNumber ' + this.partNumber.part_number + ' saved successfully ', '', {
          duration: 1500,
        });
        // reset part number form
        this.partNumberForm.reset();
      }
    );
  }

}
