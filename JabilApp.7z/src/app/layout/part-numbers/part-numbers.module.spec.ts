import { PartNumbersModule } from './part-numbers.module';

describe('PartNumbersModule', () => {
  let partNumbersModule: PartNumbersModule;

  beforeEach(() => {
    partNumbersModule = new PartNumbersModule();
  });

  it('should create an instance', () => {
    expect(partNumbersModule).toBeTruthy();
  });
});
