import { Building, PartNumber } from './';
/**
 * This Class will represent the Customer Model
 */
export class Customer {
    pk_customer: number;
    customer: string;
    prefix: string;
    fk_buildings: number;
    available: boolean;
    building?: Building;
    partNumbers?: Array<PartNumber>;
}
