import { Customer } from './';
/**
 * This Class will represent the Building Model
 */
export class Building {
    pk_building: number;
    building: string;
    available: boolean;
    customer?: Customer;
}
