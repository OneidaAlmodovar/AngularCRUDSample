import { Customer } from './';
/**
 * This Class will represent the PartNumber Model
 */
export class PartNumber {
    pk_part_number: number;
    part_number: string;
    fk_customers: number;
    available: boolean;
    customer?: Customer;
}
