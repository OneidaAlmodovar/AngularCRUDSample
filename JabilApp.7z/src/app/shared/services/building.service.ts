import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Building } from '../models';

import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BuildingService {
  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  /** GET building from the server */
  getBuilding(id: number): Observable<Building> {
    return this.http.get<any>(this.apiUrl + 'building/' + id)
      .pipe(
      catchError(this.handleError('getBuilding'))
      );
  }

  /** GET building from the server */
  getBuildingWithCustomers(id: number): Observable<Building> {
    return this.http.get<any>(this.apiUrl + 'building/customer/' + id)
      .pipe(
      catchError(this.handleError('getBuildingWithCustomers'))
      );
  }

  /** GET buildings from the server */

  getBuildings(): Observable<Building[]> {
    return this.http.get<Building[]>(this.apiUrl + 'building')
      .pipe(
      catchError(this.handleError('getBuildings', []))
      );
  }

  /**
   * Save Building Model to server thru web api
   * @param building Building model to be saved
   */
  saveBuilding(building: Building): Observable<Building> {
    console.log(building);
    return this.http.post<Building>(this.apiUrl + 'building', building).pipe(
      catchError(this.handleError<Building>('saveBuilding'))
    );
  }

  updateBuilding(building: Building): Observable<Building> {
    return this.http.put<Building>(this.apiUrl + 'building', building).pipe(
      catchError(this.handleError<Building>('updateBuilding'))
    );
  }

  /**
  * Handle Http operation that failed.
  * Let the app continue.
  * @param operation - name of the operation that failed
  * @param result - optional value to return as the observable result
  */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
