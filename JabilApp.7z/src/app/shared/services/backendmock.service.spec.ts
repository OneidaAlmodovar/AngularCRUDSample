import { TestBed, inject } from '@angular/core/testing';

import { BackendmockService } from './backendmock.service';

describe('BackendmockService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BackendmockService]
    });
  });

  it('should be created', inject([BackendmockService], (service: BackendmockService) => {
    expect(service).toBeTruthy();
  }));
});
