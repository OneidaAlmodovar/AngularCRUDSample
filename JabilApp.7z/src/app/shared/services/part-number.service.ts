import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Customer, PartNumber } from '../models';

import { environment } from '../../../environments/environment';



@Injectable({
  providedIn: 'root'
})
export class PartNumberService {

  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  /** GET part number from the server */
  PartNumber(id: number): Observable<PartNumber> {
    return this.http.get<any>(this.apiUrl + 'partNumber/' + id)
      .pipe(
        catchError(this.handleError('PartNumber'))
      );
  }

  /** GET part number from the server */
  PartNumberSearch(partNumber: PartNumber, useOR: boolean): Observable<PartNumber[]> {
    let url: string = this.apiUrl + 'partNumber/find?';
    const values: string[] = [];
    if (partNumber.part_number) {
      values.push('partNumber=' + partNumber.part_number);
    }
    if (partNumber.fk_customers) {
      values.push('customerId=' + partNumber.fk_customers);
    }
    values.push('available=' + partNumber.available);
    values.push('useOR=' + useOR);
    url += values.join('&');
    return this.http.get<PartNumber[]>(url)
      .pipe(
        catchError(this.handleError('PartNumbers', []))
      );
  }

  /** GET part number from the server */
  PartNumberWithBuilding(id: number): Observable<PartNumber> {
    return this.http.get<any>(this.apiUrl + 'partNumber/partNumber/' + id)
      .pipe(
        catchError(this.handleError('PartNumberWithCustomers'))
      );
  }

  /** GET part numbers from the server */

  PartNumbers(): Observable<PartNumber[]> {
    return this.http.get<PartNumber[]>(this.apiUrl + 'partNumber')
      .pipe(
        catchError(this.handleError('PartNumbers', []))
      );
  }

  /**
   * Save PartNumber Model to server thru web api
   * @param partNumber PartNumber model to be saved
   */
  savePartNumber(partNumber: PartNumber): Observable<PartNumber> {
    return this.http.post<any>(this.apiUrl + 'partNumber', partNumber).pipe(
      catchError(this.handleError<PartNumber>('savePartNumber'))
    );
  }
  /**
   * Update PartNumber Model to server thru web api
   * @param partNumber PartNumber model to be saved
   */
  updatePartNumber(partNumber: PartNumber): Observable<PartNumber> {
    return this.http.put<PartNumber>(this.apiUrl + 'partNumber', partNumber).pipe(
      catchError(this.handleError<PartNumber>('updatePartNumber'))
    );
  }

  /**
  * Handle Http operation that failed.
  * Let the app continue.
  * @param operation - name of the operation that failed
  * @param result - optional value to return as the observable result
  */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
