import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Customer, Building } from '../models';

import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  /** GET customer from the server */
  getCustomer(id: number): Observable<Customer> {
    return this.http.get<any>(this.apiUrl + 'customer/' + id)
      .pipe(
        catchError(this.handleError('getCustomer'))
      );
  }

  /** GET customer from the server */
  getCustomerWithBuilding(id: number): Observable<Customer> {
    return this.http.get<any>(this.apiUrl + 'customer/customer/' + id)
      .pipe(
        catchError(this.handleError('getCustomerWithCustomers'))
      );
  }

  /** GET customers from the server */

  getCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.apiUrl + 'customer')
      .pipe(
        catchError(this.handleError('getCustomers', []))
      );
  }

  /**
   * Save Customer Model to server thru web api
   * @param customer Customer model to be saved
   */
  saveCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.apiUrl + 'customer', customer).pipe(
      catchError(this.handleError<Customer>('saveCustomer'))
    );
  }
  /**
   * Update Customer Model to server thru web api
   * @param customer Customer model to be saved
   */
  updateCustomer(customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(this.apiUrl + 'customer', customer).pipe(
      catchError(this.handleError<Customer>('updateCustomer'))
    );
  }

  /**
  * Handle Http operation that failed.
  * Let the app continue.
  * @param operation - name of the operation that failed
  * @param result - optional value to return as the observable result
  */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
