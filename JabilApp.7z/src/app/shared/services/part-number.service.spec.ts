import { TestBed, inject } from '@angular/core/testing';

import { PartNumberService } from './part-number.service';

describe('PartNumberService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PartNumberService]
    });
  });

  it('should be created', inject([PartNumberService], (service: PartNumberService) => {
    expect(service).toBeTruthy();
  }));
});
