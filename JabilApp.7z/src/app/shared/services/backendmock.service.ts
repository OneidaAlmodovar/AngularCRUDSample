import { Injectable } from '@angular/core';
import {
  HttpRequest, HttpResponse, HttpHandler, HttpEvent,
  HttpInterceptor, HTTP_INTERCEPTORS
  } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, mergeMap, materialize, dematerialize } from 'rxjs/operators';
import { Building, Customer, PartNumber } from '../models';

@Injectable({
  providedIn: 'root'
})
export class BackendmockService {

  constructor() { }
  /**
   * Method used to intercept Http requests and provide mock information in order to test
   * api calls that are not already created
   * @param request HttpRequest object used to get request information
   * @param next HttpHandler used to continuew with the request if is not defined on the mocks
   */
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const testUser = { id: 1, username: 'test', password: 'test', firstName: 'Test', lastName: 'User' };
    // wrap in delayed observable to simulate server api call
    return of(null).pipe(mergeMap(() => {

      // get buildings
      // if (request.url.endsWith('api/building') && request.method === 'GET') {
      //   const buildings = this.mockBuildings();
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: buildings }));
      // }

      // get building by id
      // if (request.url.endsWith('api/building/') && request.method === 'GET') {
      //   const testBuilding = new Building();
      //   testBuilding.pk_building = 1;
      //   testBuilding.building = 'test';
      //   testBuilding.available = true;
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: testBuilding }));
      // }

      // post buildings
      // if (request.url.endsWith('api/building') && request.method === 'POST') {
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: request.body }));
      // }

      // get customers
      // if (request.url.endsWith('api/customer') && request.method === 'GET') {
      //   const customers = this.mockCustomers();
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: customers }));
      // }

      // post customers
      // if (request.url.endsWith('api/customer') && request.method === 'POST') {
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: request.body }));
      // }

      // get customers
      // if (request.url.endsWith('api/partNumber') && request.method === 'GET') {
      //   const customers = this.mockPartNumbers();
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: customers }));
      // }

      // post customers
      // if (request.url.endsWith('api/partNumber') && request.method === 'POST') {
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: request.body }));
      // }

      // post customers
      // if (request.url.endsWith('api/partNumber/') && request.method === 'GET') {
      //   const mockPartNumber = new PartNumber();
      //   mockPartNumber.pk_part_number = 1;
      //   mockPartNumber.part_number = 'test 1';
      //   mockPartNumber.available = true;
      //   mockPartNumber.fk_customer = 1;
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: mockPartNumber }));
      // }

      // if (request.url.match(/(api\/partNumber\/)\w*\//)) {
      //    const customers = this.mockPartNumbers();
      //   // implemented server side in a real application
      //   return of(new HttpResponse({ status: 200, body: customers }));
      // }

      // pass through any requests not handled above
      return next.handle(request);

    }))

      // call materialize and dematerialize to ensure delay even if an error is thrown
      // (https://github.com/Reactive-Extensions/RxJS/issues/648)
      .pipe(materialize())
      .pipe(delay(500))
      .pipe(dematerialize());
  }

  mockBuildings(): Array<Building> {
    const buildings: Array<Building> = [];
    for (let i = 1; i <= 10; i++) {
      const mockBuilding = new Building();
      mockBuilding.pk_building = i;
      mockBuilding.building = 'test ' + i;
      mockBuilding.available = true;
      buildings.push(mockBuilding);
    }
    return buildings;
  }

  mockCustomers(): Array<Customer> {
    const customers: Array<Customer> = [];
    for (let i = 1; i <= 10; i++) {
      const mockCustomer = new Customer();
      mockCustomer.pk_customer = i;
      mockCustomer.customer = 'test ' + i;
      mockCustomer.available = true;
      mockCustomer.fk_buildings = 1;
      customers.push(mockCustomer);
    }
    return customers;
  }
  mockPartNumbers(): Array<PartNumber> {
    const partNumbers: Array<PartNumber> = [];
    for (let i = 1; i <= 10; i++) {
      const mockPartNumber = new PartNumber();
      mockPartNumber.pk_part_number = i;
      mockPartNumber.part_number = 'test ' + i;
      mockPartNumber.available = true;
      mockPartNumber.fk_customers = 1;
      partNumbers.push(mockPartNumber);
    }
    return partNumbers;
  }
}


export let mockBackendProvider = {
  // use fake backend in place of Http service for backend-less development
  provide: HTTP_INTERCEPTORS,
  useClass: BackendmockService,
  multi: true
};
