import { NgModule } from '@angular/core';
import {
  MatButtonModule, MatCheckboxModule, MatSidenavModule, MatListModule, MatIconModule,
  MatToolbarModule, MatTabsModule, MatInputModule, MatChipsModule, MatCardModule, MatBadgeModule,
  MatGridListModule, MatDividerModule, MatTableModule, MatPaginatorModule, MatSortModule, MatAutocompleteModule,
  MatFormFieldModule, MatSnackBarModule
} from '@angular/material';

import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  imports: [ FormsModule, ReactiveFormsModule,
    MatButtonModule, MatCheckboxModule, MatSidenavModule, MatListModule, MatIconModule,
    MatToolbarModule, MatTabsModule, MatInputModule, MatChipsModule, MatCardModule, MatBadgeModule,
    MatGridListModule, MatDividerModule, MatTableModule, MatPaginatorModule, MatSortModule, MatAutocompleteModule,
    MatFormFieldModule, MatSnackBarModule,
    CdkTableModule
  ],
  exports: [ FormsModule, ReactiveFormsModule,
    MatButtonModule, MatCheckboxModule, MatSidenavModule, MatListModule, MatIconModule,
    MatToolbarModule, MatTabsModule, MatInputModule, MatChipsModule, MatCardModule, MatBadgeModule,
    MatGridListModule, MatDividerModule, MatTableModule, MatPaginatorModule, MatSortModule, MatAutocompleteModule,
    MatFormFieldModule, MatSnackBarModule,
    CdkTableModule
  ],
  providers: []
})
export class MaterialCompModule {
  // public matIconRegistry: MatIconRegistry
  constructor() {
    // matIconRegistry.registerFontClassAlias('fontawesome', 'fa');
    // matIconRegistry.registerFontClassAlias('fontawesome', 'fab');
    // matIconRegistry.registerFontClassAlias('fontawesome', 'fas');
    // matIconRegistry.registerFontClassAlias('fontawesome', 'far');
  }

}
