﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataAccess.DTO;
namespace DataAccess.DAO
{
    public class BuildingDAO
    {
        public int CreateBuilding(BuildingDTO building)
        {
            string sqlString = @"INSERT INTO [dbo].[Buildings] ([building],
                [available]) VALUES (@Building,@Available);
                SELECT CAST(scope_identity() AS int) ";

            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@Building", SqlDbType.NVarChar, 100, ParameterDirection.Input, building.building);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, building.available);
            return (int)MsSqlHelper.ExecuteScalarCommand(command, MsSqlHelper.ConnectionString);

        }

        public bool DeleteBuilding(int buildingID)
        {
            string sqlString = "delete from [dbo].[Buildings] where pk_building=@BuildingID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@BuildingID", SqlDbType.Int, 0, ParameterDirection.Input, buildingID);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));
        }

        public bool UpdateBuilding(Building building)
        {
            string sqlString = @"UPDATE [dbo].[Buildings]
                                   SET [building] = @Building
                                      ,[available] = @Available
                                 where pk_building=@BuildingID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@Building", SqlDbType.NVarChar, 100, ParameterDirection.Input, building.building1);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, building.available);
            MsSqlHelper.AddParamToSQLCmd(command, "@BuildingID", SqlDbType.Int, 0, ParameterDirection.Input, building.pk_building);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));

        }

        public List<BuildingDTO> GetBuildings()
        {
            string sqlString = "select * from Buildings";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    List<BuildingDTO> buildings = new List<BuildingDTO>();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            BuildingDTO building = new BuildingDTO((int)dataReader["pk_building"], (string)dataReader["building"], 
                                (bool)dataReader["available"]);

                            buildings.Add(building);
                        }
                    }
                    return buildings;

                }
            }


        }

        public BuildingDTO GetBuilding(int buildingID)
        {
            string sqlString = "select * from Buildings where pk_building=@BuildingID";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                MsSqlHelper.AddParamToSQLCmd(command, "@BuildingID", SqlDbType.Int, 0, ParameterDirection.Input, buildingID);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    BuildingDTO building = null;
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            building = new BuildingDTO((int)dataReader["pk_building"], (string)dataReader["building"],
                                (bool)dataReader["available"]);

                        }
                    }
                    return building;

                }
            }


        }
    }
}
