﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataAccess.DTO;

namespace DataAccess.DAO
{
    public class CustomerDAO
    {
        public int CreateCustomer(CustomerDTO customer)
        {
            string sqlString = @"INSERT INTO [dbo].[Customers] ([customer] ,[prefix] ,[fk_buildings] ,[available])
                    VALUES (@Customer,@Prefix,@FK_Buildings,@Available);
                    SELECT CAST(scope_identity() AS int) ";

            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@Customer", SqlDbType.NVarChar, 100, ParameterDirection.Input, customer.customer);
            MsSqlHelper.AddParamToSQLCmd(command, "@Prefix", SqlDbType.NVarChar, 5, ParameterDirection.Input, customer.prefix);
            MsSqlHelper.AddParamToSQLCmd(command, "@FK_Buildings", SqlDbType.Int, 0, ParameterDirection.Input, customer.fk_buildings);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, customer.available);
            return (int)MsSqlHelper.ExecuteScalarCommand(command, MsSqlHelper.ConnectionString);

        }

        public bool DeleteCustomer(int CustomerID)
        {
            string sqlString = "delete from [dbo].[Customers] where pk_customer=@CustomerID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@CustomerID", SqlDbType.Int, 0, ParameterDirection.Input, CustomerID);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));
        }
        /// <returns>Returns boolean</returns>
        public bool UpdateCustomer(CustomerDTO customer)
        {
            string sqlString = @"UPDATE [dbo].[Customers]
                                   SET [customer] = @Customer
                                      ,[prefix] = @Prefix
                                      ,[fk_buildings] = @FK_Buildings
                                      ,[available] = @Available
                                 WHERE  pk_customer=@CustomerID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@Customer", SqlDbType.NVarChar, 100, ParameterDirection.Input, customer.customer);
            MsSqlHelper.AddParamToSQLCmd(command, "@Prefix", SqlDbType.NVarChar, 5, ParameterDirection.Input, customer.prefix);
            MsSqlHelper.AddParamToSQLCmd(command, "@FK_Buildings", SqlDbType.Int, 0, ParameterDirection.Input, customer.fk_buildings);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, customer.available); 
            MsSqlHelper.AddParamToSQLCmd(command, "@CustomerID", SqlDbType.Int, 0, ParameterDirection.Input, customer.pk_customer);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));

        }

        public List<CustomerDTO> GetCustomers()
        {
            string sqlString = "select * from [dbo].[Customers]";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    List<CustomerDTO> buildings = new List<CustomerDTO>();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            CustomerDTO building = new CustomerDTO((int)dataReader["pk_customer"], (string)dataReader["customer"],
                                (string)dataReader["prefix"], (int)dataReader["fk_buildings"], (bool)dataReader["available"]);

                            buildings.Add(building);
                        }
                    }
                    return buildings;

                }
            }


        }

        public CustomerDTO GetCustomer(int customerID)
        {
            string sqlString = "select * from [dbo].[Customers] where pk_customer=@CustomerID";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                MsSqlHelper.AddParamToSQLCmd(command, "@CustomerID", SqlDbType.Int, 0, ParameterDirection.Input, customerID);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    CustomerDTO customer = null;
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            customer = new CustomerDTO((int)dataReader["pk_customer"], (string)dataReader["customer"],
                                (string)dataReader["prefix"], (int)dataReader["fk_buildings"], (bool)dataReader["available"]);

                        }
                    }
                    return customer;

                }
            }


        }
    }
}
