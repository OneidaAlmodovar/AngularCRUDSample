﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace DataAccess.DAO
{
    class MsSqlHelper
    {
        public static string ConnectionString
        {
            get
            {
                return Properties.Settings.Default.jabildbConnectionString;
                /*
                if (ConfigurationManager.ConnectionStrings["JabilDataModel"].ConnectionString == null)
                    throw new NullReferenceException("JabilDataModel connectionString configuration is missing from your web.config.");
                string connectionString = ConfigurationManager.ConnectionStrings["JabilDataModel"].ConnectionString;
                if (String.IsNullOrEmpty(connectionString))
                    throw new NullReferenceException("JabilDataModel connectionString configuration is missing from your web.config.");
                else
                    return connectionString;
                */
            }


        }

        public static void AddParamToSQLCmd(SqlCommand sqlCmd,
                                      string paramId,
                                      SqlDbType sqlType,
                                      int paramSize,
                                      ParameterDirection paramDirection,
                                      object paramvalue)
        {

            if (sqlCmd == null)
                throw (new ArgumentNullException("sqlCmd"));
            if (string.IsNullOrEmpty(paramId))
                throw (new ArgumentOutOfRangeException("paramId"));

            SqlParameter newSqlParam = new SqlParameter();
            newSqlParam.ParameterName = paramId;
            newSqlParam.SqlDbType = sqlType;
            newSqlParam.Direction = paramDirection;

            if (paramSize > 0)
                newSqlParam.Size = paramSize;

            if (paramvalue != null)
                newSqlParam.Value = paramvalue;

            sqlCmd.Parameters.Add(newSqlParam);

        }


        public static object ExecuteScalarCommand(SqlCommand command, string connectionString)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                if (command == null)
                    throw new ArgumentNullException("Command param is null where it must be an object.");
                connection.Open();
                command.Connection = connection;
                return command.ExecuteScalar();


            }

        }



        public static int ExecuteNonQueryCommand(SqlCommand command, string connnectionString)
        {

            using (SqlConnection connection = new SqlConnection(connnectionString))
            {

                if (command == null)
                    throw new ArgumentNullException("Command param is null where it must be an object.");
                connection.Open();
                command.Connection = connection;
                return command.ExecuteNonQuery();


            }

        }
    }
}
