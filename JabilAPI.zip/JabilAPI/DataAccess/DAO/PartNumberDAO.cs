﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataAccess.DTO;

namespace DataAccess.DAO
{
    public class PartNumberDAO
    {
        public int CreatePartNumber(PartNumberDTO partNumber)
        {
            string sqlString = @"INSERT INTO [dbo].[Part_Numbers] ([part_number] ,[fk_customers] ,[available])
                    VALUES (@PartNumber ,@FK_Customers ,@Available);
                        SELECT CAST(scope_identity() AS int) ";

            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@PartNumber", SqlDbType.NVarChar, 50, ParameterDirection.Input, partNumber.part_number);
            MsSqlHelper.AddParamToSQLCmd(command, "@FK_Customers", SqlDbType.Int, 0, ParameterDirection.Input, partNumber.fk_customers);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, partNumber.available);
            return (int)MsSqlHelper.ExecuteScalarCommand(command, MsSqlHelper.ConnectionString);

        }

        public bool DeletePartNumber(int partNumberID)
        {
            string sqlString = "delete from [dbo].[Part_Numbers] where pk_part_number=@PartNumberID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@PartNumberID", SqlDbType.Int, 0, ParameterDirection.Input, partNumberID);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));
        }

        public bool UpdatePartNumber(PartNumberDTO partNumber)
        {
            string sqlString = @"UPDATE [dbo].[Part_Numbers]
                                   SET [part_number] = @PartNumber
                                      ,[fk_customers] = @FK_Customers
                                      ,[available] = @Available
                                 WHERE  pk_part_number=@PartNumberID";
            SqlCommand command = new SqlCommand(sqlString);
            MsSqlHelper.AddParamToSQLCmd(command, "@PartNumber", SqlDbType.NVarChar, 50, ParameterDirection.Input, partNumber.part_number);
            MsSqlHelper.AddParamToSQLCmd(command, "@FK_Customers", SqlDbType.Int, 0, ParameterDirection.Input, partNumber.fk_customers);
            MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, partNumber.available);
            MsSqlHelper.AddParamToSQLCmd(command, "@PartNumberID", SqlDbType.Int, 0, ParameterDirection.Input, partNumber.pk_part_number);
            return Convert.ToBoolean(MsSqlHelper.ExecuteNonQueryCommand(command, MsSqlHelper.ConnectionString));

        }

        public List<PartNumberDTO> GetPartNumbers()
        {
            string sqlString = "select * from [dbo].[Part_Numbers]";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    List<PartNumberDTO> buildings = new List<PartNumberDTO>();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            PartNumberDTO building = new PartNumberDTO((int)dataReader["pk_part_number"], (string)dataReader["part_number"],
                                (int)dataReader["fk_customers"], (bool)dataReader["available"]);

                            buildings.Add(building);
                        }
                    }
                    return buildings;

                }
            }


        }

        public PartNumberDTO GetPartNumber(int partNumberID)
        {
            string sqlString = "select * from [dbo].[Part_Numbers]  WHERE  pk_part_number=@PartNumberID";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                MsSqlHelper.AddParamToSQLCmd(command, "@PartNumberID", SqlDbType.Int, 0, ParameterDirection.Input, partNumberID);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    PartNumberDTO building = null;
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            building = new PartNumberDTO((int)dataReader["pk_part_number"], (string)dataReader["part_number"],
                                (int)dataReader["fk_customers"], (bool)dataReader["available"]);

                        }
                    }
                    return building;

                }
            }


        }

        public List<PartNumberDTO> FindPartNumbers(bool useOR, string PartNumber, int? fk_customers, bool? available)
        {
            string sqlString = @"select p.pk_part_number, p.part_number,p.fk_customers, p.available,c.customer,c.prefix,b.building
                                    from Part_Numbers p 
                                    inner join customers c on p.fk_customers = c.pk_customer
                                    inner join Buildings b on c.fk_buildings = b.pk_building
                                where p.part_number like @PartNumber ";
            string predicateCombinator = useOR ? "or" : "and";
            if (fk_customers != null)
                sqlString += predicateCombinator + " p.fk_customers = @FK_Customers ";
            if (available != null)
                sqlString += predicateCombinator + "  p.available = @Available";
            sqlString += ";";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                string searchTerm = string.Format("%{0}%", PartNumber);
                MsSqlHelper.AddParamToSQLCmd(command, "@PartNumber", SqlDbType.NVarChar, 52, ParameterDirection.Input, searchTerm);
                if (fk_customers != null)
                    MsSqlHelper.AddParamToSQLCmd(command, "@FK_Customers", SqlDbType.Int, 0, ParameterDirection.Input, fk_customers.GetValueOrDefault());
                if (available != null)
                    MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, available.GetValueOrDefault());
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    List<PartNumberDTO> partNumbers = new List<PartNumberDTO>();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            PartNumberDTO partNumber = new PartNumberDTO((int)dataReader["pk_part_number"], (string)dataReader["part_number"],
                                (int)dataReader["fk_customers"], (bool)dataReader["available"]);
                            partNumber.Customer = (new CustomerDAO()).GetCustomer(partNumber.fk_customers);
                            partNumber.Customer.Building = (new BuildingDAO()).GetBuilding(partNumber.Customer.fk_buildings);
                            partNumbers.Add(partNumber);
                        }
                    }
                    return partNumbers;

                }
            }


        }

        public List<PartNumberDTO> FindByPartAndAvailable(string PartNumber, bool available)
        {
            string sqlString = @"select p.part_number, p.available,c.customer,c.prefix,b.building
                                    from Part_Numbers p 
                                    inner join customers c on p.fk_customers = c.pk_customer
                                    inner join Buildings b on c.fk_buildings = b.pk_building
                                where p.part_number like %@PartNumber% or p.available = @Available; ";
            using (SqlConnection connection = new SqlConnection(MsSqlHelper.ConnectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlString, connection);
                MsSqlHelper.AddParamToSQLCmd(command, "@PartNumber", SqlDbType.NVarChar, 50, ParameterDirection.Input, PartNumber);
                MsSqlHelper.AddParamToSQLCmd(command, "@Available", SqlDbType.Bit, 0, ParameterDirection.Input, available);
                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    List<PartNumberDTO> partNumbers = new List<PartNumberDTO>();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {

                            PartNumberDTO partNumber = new PartNumberDTO((int)dataReader["pk_part_number"], (string)dataReader["part_number"],
                                (int)dataReader["fk_customers"], (bool)dataReader["available"]);
                            partNumber.Customer = (new CustomerDAO()).GetCustomer(partNumber.fk_customers);
                            partNumber.Customer.Building = (new BuildingDAO()).GetBuilding(partNumber.Customer.fk_buildings);

                            partNumbers.Add(partNumber);
                        }
                    }
                    return partNumbers;

                }
            }


        }

    }
}
