﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class PartNumberDTO
    {
        public PartNumberDTO() { }
        public PartNumberDTO(int pk_part_number, string part_number, int fk_customers, bool available)
        {
            this.pk_part_number = pk_part_number;
            this.part_number = part_number;
            this.fk_customers = fk_customers;
            this.available = available;
        }
        public int pk_part_number { get; set; }
        public string part_number { get; set; }
        public int fk_customers { get; set; }
        public bool available { get; set; }
        public virtual CustomerDTO Customer {get; set;}
    }
}
