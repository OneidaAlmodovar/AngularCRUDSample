﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class CustomerDTO
    {
        public CustomerDTO()
        {
            this.Part_Numbers = new HashSet<PartNumberDTO>();
        }
        public CustomerDTO(int pk_customer, string customer, string prefix,
            int fk_buildings,bool available)
        {
            this.pk_customer = pk_customer;
            this.customer = customer;
            this.prefix = prefix;
            this.fk_buildings = fk_buildings;
            this.available = available;
            this.Part_Numbers = new HashSet<PartNumberDTO>();
        }

        public int pk_customer { get; set; }
        public string customer { get; set; }
        public string prefix { get; set; }
        public int fk_buildings { get; set; }
        public bool available { get; set; }
        public virtual BuildingDTO Building{ get; set; }
        public virtual ICollection<PartNumberDTO> Part_Numbers { get; set; }
    }
}
