﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class BuildingDTO
    {
        public BuildingDTO()
        {
            this.Customers = new HashSet<CustomerDTO>();
        }

        public BuildingDTO(int pk_building, string building, bool available)
        {
            this.pk_building = pk_building;
            this.building = building;
            this.available = available;
        }

        public int pk_building { get; set; }
        public string building { get; set; }
        public bool available { get; set; }
        public virtual ICollection<CustomerDTO> Customers { get; set; }
    }
}
