﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DataAccess;
using DataAccess.DAO;
using DataAccess.DTO;

namespace JabilAPI.Controllers
{
    public class PartNumberController : ApiController
    {
        PartNumberDAO partNumberDao = new PartNumberDAO();
        public IEnumerable<PartNumberDTO> Get()
        {
            return partNumberDao.GetPartNumbers();

        }

        public PartNumberDTO Get(int id)
        {
            return partNumberDao.GetPartNumber(id);
        }

        [Route("api/PartNumber/find/")]
        [HttpGet]
        public IEnumerable<PartNumberDTO> FindByPartCustomerAndAvailable(bool useOR, string partNumber="", int? customerId=null, bool? available=null) {
            return partNumberDao.FindPartNumbers(useOR, partNumber, customerId, available);
        }

        /*
        [Route("api/PartNumber/find/{partNumber}/{customerId}/{available}")]
        [Route("api/PartNumber/find/{partNumber}/{available}")]
        [HttpGet]
        public IEnumerable<PartNumberDTO> FindByPartAndAvailable(string partNumber, bool available)
        {
            return partNumberDao.GetPartNumbers();
        }
        */

        // POST api/customer
        public IHttpActionResult Post([FromBody] PartNumberDTO value)
        {
            partNumberDao.CreatePartNumber(value);

            return Ok();
        }
        // PUT api/customer/5
        public IHttpActionResult Put(int id, [FromBody] PartNumberDTO value)
        {
            return Ok();
        }
    }
}
