﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DataAccess.DAO;
using DataAccess.DTO;

namespace JabilAPI.Controllers
{
    public class CustomerController : ApiController
    {
        CustomerDAO customerDao = new CustomerDAO();

        // GET api/customer
        public IEnumerable<CustomerDTO> Get()
        {
            return customerDao.GetCustomers();

        }
        // GET api/customer/5
        public CustomerDTO Get(int id)
        {
            return customerDao.GetCustomer(id);
        }

        // POST api/customer
        public IHttpActionResult Post([FromBody] CustomerDTO value)
        {
            customerDao.CreateCustomer(value);

            return Ok();
        }
        // PUT api/customer/5
        public IHttpActionResult Put(int id, [FromBody] CustomerDTO value)
        {
            return Ok();
        }
    }
}
