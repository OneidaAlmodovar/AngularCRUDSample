﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DataAccess;
using DataAccess.DAO;
using DataAccess.DTO;


namespace JabilAPI.Controllers
{
    public class BuildingController : ApiController
    {
        BuildingDAO buildingDao = new BuildingDAO();
        public IEnumerable<BuildingDTO> Get()
        {
            return buildingDao.GetBuildings();

        }

        public Building Get(int id)
        {
            using (jabildbEntities entities = new jabildbEntities())
            {
                return entities.Buildings.FirstOrDefault(b => b.pk_building == id);
            }
        }
        // POST api/values
        public IHttpActionResult Post([FromBody] BuildingDTO value)
        {
            buildingDao.CreateBuilding(value);

            return Ok();
        }
        // PUT api/values/5
        public IHttpActionResult Put(int id, [FromBody]string value)
        {
            return Ok();
        }
    }
}
